package hotelManagementSystem;

public interface BookingMethods {

     void makeBooking();
     void seeBookingDetails();
    ;
}
