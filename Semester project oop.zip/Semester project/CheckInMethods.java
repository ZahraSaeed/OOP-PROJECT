package hotelManagementSystem;

public interface CheckInMethods {
     void showCheckInDetails();
     void checkIn();
    void  showAllCheckIn();
}
